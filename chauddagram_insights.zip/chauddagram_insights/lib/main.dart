import 'package:chauddagram_insights/bottom_nav.dart';
import'package:flutter/material.dart';

import 'package:chauddagram_insights/custom_drawer.dart';
import 'views/home_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      debugShowCheckedModeBanner: false,

      title: 'Chauddagram Insights',

      theme: ThemeData(

        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),

      home: const BottomNav()



    );
  }
}



