package com.noorsoft.chauddagram_insights

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
